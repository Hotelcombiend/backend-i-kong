package com.example.ordersservice.controller.event;

import lombok.Data;

@Data
public class DelOrderEvent {
    private String _id;
}
