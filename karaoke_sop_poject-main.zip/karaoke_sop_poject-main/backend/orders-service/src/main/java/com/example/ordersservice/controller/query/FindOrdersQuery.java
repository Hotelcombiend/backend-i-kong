package com.example.ordersservice.controller.query;

public class FindOrdersQuery {
}
