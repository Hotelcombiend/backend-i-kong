package com.example.paymentservice.controller.query;

public class FindPaymentsQuery {
}
