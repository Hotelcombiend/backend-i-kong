package com.example.paymentservice.controller.event;

import lombok.Data;

@Data
public class DelPaymentEvent {
    private String _id;
}
