package com.example.foodmenuservice.controller.query;

public class FindFoodMenuQuery {
}
