package com.example.foodmenuservice.controller.event;

import lombok.Data;

@Data
public class DelFoodMenuEvent {
    private String _id;
}
