package com.example.foodmenuservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodmenuServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodmenuServiceApplication.class, args);
	}

}
