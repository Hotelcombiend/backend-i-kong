package com.example.roomservice.controller.event;

import lombok.Data;

@Data
public class DelRoomEvent {
    private String _id;
}
