package com.example.roomservice.controller.query;

public class FindRoomsQuery {
}
