package com.example.roomservice.controller.command.Model;

import lombok.Data;

import java.util.List;
@Data
public class Rooms {
    private List<RoomModel> rooms;
}
